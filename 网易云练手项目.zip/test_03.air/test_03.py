# -*- encoding=utf8 -*-
__author__ = "llw"

from airtest.core.api import *

auto_setup(__file__)

elements = [
    Template(r"tpl1716569113646.png", record_pos=(-0.317, -0.051), resolution=(1440, 3200)),
    Template(r"tpl1716569129959.png", record_pos=(-0.096, -0.061), resolution=(1440, 3200)),
    Template(r"tpl1716569420447.png", record_pos=(0.102, -0.055), resolution=(1440, 3200)),
    Template(r"tpl1716569435898.png", record_pos=(0.326, -0.079), resolution=(1440, 3200)),
    Template(r"tpl1716569449634.png", record_pos=(-0.31, 0.269), resolution=(1440, 3200)),
    Template(r"tpl1716569460334.png", record_pos=(-0.105, 0.274), resolution=(1440, 3200)),
    Template(r"tpl1716569474790.png", record_pos=(0.113, 0.263), resolution=(1440, 3200)),
    Template(r"tpl1716569485715.png", record_pos=(0.328, 0.278), resolution=(1440, 3200))



    
]
#     while  exists(Template(r"tpl1716568382996.png", record_pos=(-0.008, -0.426), resolution=(1440, 3200))):
#         if time.time() - start_time > timeout:
#             print("等待超时，未找到模板")
#             break
#         else:
#             print("等待模板出现...")
#             sleep(1)
# 设置要循环的次数
loop_count = 2

for element in elements:
    for i in range(loop_count):


        touch(element)
        # 可以在这里添加一些等待时间或其他操作，例如：
        sleep(50)  # 等待1秒，确保页面反应完全

